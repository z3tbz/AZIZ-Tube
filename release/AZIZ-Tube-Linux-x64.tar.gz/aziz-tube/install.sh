#!/bin/sh
# AZIZ Tube for Linux: adds it to your applications menu (for you only, no root). Needs mpv: sudo apt install mpv
DIR="$(cd "$(dirname "$0")" && pwd)"
chmod +x "$DIR/aziz-tube"
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/aziz-tube.desktop" <<D
[Desktop Entry]
Name=AZIZ Tube
Exec="$DIR/aziz-tube"
Icon=$DIR/aziz-tube.png
Type=Application
Categories=AudioVideo;Video;Player;
D
command -v mpv >/dev/null 2>&1 || echo "mpv is missing: install it (e.g. sudo apt install mpv / sudo dnf install mpv / sudo pacman -S mpv)"
echo "AZIZ Tube added to your applications menu."
